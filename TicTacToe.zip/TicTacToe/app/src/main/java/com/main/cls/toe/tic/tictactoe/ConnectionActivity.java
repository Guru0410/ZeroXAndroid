package com.main.cls.toe.tic.tictactoe;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import java.net.*;
import java.io.*;
import android.content.Context;
import android.os.AsyncTask;

public class ConnectionActivity extends AppCompatActivity {


    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_connection);
//        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
//        setSupportActionBar(toolbar);
//
//        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
//            }
//        });

        context = getApplicationContext();
        AsyncTask<String, Void, Void> async = new ConnectionThread();
        async.execute();

    }

}


class ConnectionThread extends AsyncTask<String, Void, Void> {

    Socket soc;
    Thread t=null;
    DataOutputStream dout;
    DataInputStream din;

    protected Void doInBackground(String... urls) {
        try {

//                soc = new Socket("192.168.2.11", 5217);
                soc = new Socket("192.168.222.102", 5217);
                din = new DataInputStream(soc.getInputStream());
                dout = new DataOutputStream(soc.getOutputStream());
                dout.writeUTF("karan");

            while(true)
            {
                try
                {
                    System.out.println(din.readUTF());
                }
                catch(Exception ex)
                {
                    ex.printStackTrace();
                }
            }

            }
            catch(Exception ex)
            {
                System.out.println(ex.getMessage());
            }
        return null;
    }

    protected void onPostExecute() {
        // TODO: check this.exception
        // TODO: do something with the feed
    }
}