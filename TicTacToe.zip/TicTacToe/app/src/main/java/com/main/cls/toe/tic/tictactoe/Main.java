package com.main.cls.toe.tic.tictactoe;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.support.design.widget.FloatingActionButton;

import java.util.Scanner;
import android.os.Handler;

import static android.graphics.Color.*;

public class Main extends AppCompatActivity implements View.OnClickListener {

    LinearLayout buttons[][];
    static TextView text[][];
    public static final int ROWS = 4, COLS = 4; // number of rows and columns
    public static int[][] board = new int[ROWS][COLS]; // game board in 2D array
    public static int[][] winner = new int[ROWS][COLS];
    //  containing (EMPTY, CROSS, NOUGHT)
    public static int currentState;  // the current state of the game
    // (PLAYING, DRAW, CROSS_WON, NOUGHT_WON)
    public static int currentPlayer; // the current player (CROSS or NOUGHT)
    public static int currntRow, currentCol; // current seed's row and column
    // Name-constants to represent the seeds and cell contents
    public static final int EMPTY = 0;
    public static final int CROSS = 1;
    public static final int NOUGHT = 2;

    public static final int PLAYING = 0;
    public static final int DRAW = 1;
    public static final int CROSS_WON = 2;
    public static final int NOUGHT_WON = 3;
    public static Scanner in = new Scanner(System.in); // the input Scanner
    boolean validInput = false;
    int rowMove, colMove;
    TextView btnConnect;
    Handler handler;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.grid);
//        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
//        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                initGame();
            }
        });
        context = this;
        handler = new Handler();
        buttons = new LinearLayout[4][4];
        text = new TextView[4][4];

        initiallize();

        for (int row = 1; row < ROWS; ++row) {
            for (int col = 1; col < COLS; ++col) {

                System.out.println("::::::::::::" + ROWS + ":::::::" + COLS);
                buttons[row][col].setOnClickListener(this);
            }
        }

        initGame();

    }

    /** Update the "currentState" after the player with "theSeed" has placed on
     (currentRow, currentCol). */
    public void updateGame(int theSeed, int currentRow, int currentCol) {

        if (theSeed == CROSS) {
            text[currentRow][currentCol].setText("X");
            text[currentRow][currentCol].setTextColor(Color.parseColor("#FF9E27"));
        } else {
            text[currentRow][currentCol].setText("O");
            text[currentRow][currentCol].setTextColor(Color.parseColor("#F42B6F"));
        }

        if (hasWon(theSeed, currentRow, currentCol))
        {
            currentState = (theSeed == CROSS) ? CROSS_WON : NOUGHT_WON;

            for (int row = 1; row < ROWS; ++row) {
                for (int col = 1; col < COLS; ++col) {
                    if(winner[row][col] == 1) {
                        text[row][col].setTextColor(Color.parseColor("#27beff"));
                    }
                }
            }

            handler.postDelayed(new Runnable() {
                public void run() {

                    int ctr = 0;
                    System.out.println(ctr++);

                    popup();
                }
            }, 1 * 4000);

        } else if (isDraw()) {  // check for draw
            currentState = DRAW;
            popup();
        }
        // Otherwise, no change to currentState (still PLAYING).



    }

    /** Return true if it is a draw (no more empty cell) */
    // TODO: Shall declare draw if no player can "possibly" win
    public boolean isDraw() {
        for (int row = 1; row < ROWS; ++row) {
            for (int col = 1; col < COLS; ++col) {
                if (board[row][col] == EMPTY) {
                    return false;  // an empty cell found, not draw, exit
                }
            }
        }
        return true;  // no empty cell, it's a draw
    }

    /** Return true if the player with "theSeed" has won after placing at
     (currentRow, currentCol) */
    public boolean hasWon(int theSeed, int currentRow, int currentCol) {

        boolean response = false;

        if(board[currentRow][1] == theSeed         // 3-in-the-row
           && board[currentRow][2] == theSeed && board[currentRow][3] == theSeed)
        {
            winner[currentRow][1] = 1;
            winner[currentRow][2] = 1;
            winner[currentRow][3] = 1;
            response = true;
        }else if(board[1][currentCol] == theSeed      // 3-in-the-column
                && board[2][currentCol] == theSeed && board[3][currentCol] == theSeed)
        {
            winner[1][currentCol] = 1;
            winner[2][currentCol] = 1;
            winner[3][currentCol] = 1;
            response = true;
        }else if(currentRow == currentCol            // 3-in-the-diagonal
                && board[1][1] == theSeed
                && board[2][2] == theSeed
                && board[3][3] == theSeed)
        {
            winner[1][1] = 1;
            winner[2][2] = 1;
            winner[3][3] = 1;
            response = true;
        }else if(currentRow + currentCol == 4  // 3-in-the-opposite-diagonal
                && board[1][3] == theSeed
                && board[2][2] == theSeed
                && board[3][1] == theSeed)
        {
            winner[1][3] = 1;
            winner[2][2] = 1;
            winner[3][1] = 1;
            response = true;
        }

//        return (board[currentRow][1] == theSeed         // 3-in-the-row
//                && board[currentRow][2] == theSeed
//                && board[currentRow][3] == theSeed
//                || board[1][currentCol] == theSeed      // 3-in-the-column
//                && board[2][currentCol] == theSeed
//                && board[3][currentCol] == theSeed
//                || currentRow == currentCol            // 3-in-the-diagonal
//                && board[1][1] == theSeed
//                && board[2][2] == theSeed
//                && board[3][3] == theSeed
//                || currentRow + currentCol == 4  // 3-in-the-opposite-diagonal
//                && board[1][3] == theSeed
//                && board[2][2] == theSeed
//                && board[3][1] == theSeed);

        return response;
    }


    public void initiallize()
    {

        buttons[1][1] = (LinearLayout) findViewById(R.id.layout1);
        buttons[1][2] = (LinearLayout) findViewById(R.id.layout2);
        buttons[1][3] = (LinearLayout) findViewById(R.id.layout3);

        buttons[2][1] = (LinearLayout) findViewById(R.id.layout4);
        buttons[2][2] = (LinearLayout) findViewById(R.id.layout5);
        buttons[2][3] = (LinearLayout) findViewById(R.id.layout6);

        buttons[3][1] = (LinearLayout) findViewById(R.id.layout7);
        buttons[3][2] = (LinearLayout) findViewById(R.id.layout8);
        buttons[3][3] = (LinearLayout) findViewById(R.id.layout9);

        text[1][1] = (TextView) findViewById(R.id.text1);
        text[1][2] = (TextView) findViewById(R.id.text2);
        text[1][3] = (TextView) findViewById(R.id.text3);

        text[2][1] = (TextView) findViewById(R.id.text4);
        text[2][2] = (TextView) findViewById(R.id.text5);
        text[2][3] = (TextView) findViewById(R.id.text6);

        text[3][1] = (TextView) findViewById(R.id.text7);
        text[3][2] = (TextView) findViewById(R.id.text8);
        text[3][3] = (TextView) findViewById(R.id.text9);

        btnConnect = (TextView) findViewById(R.id.btnConnect);
        btnConnect.setOnClickListener(this);

    }

    public void initGame() {
        for (int row = 1; row < ROWS; ++row) {
            for (int col = 1; col < COLS; ++col) {
                board[row][col] = EMPTY;  // all cells empty
                winner[row][col] = EMPTY;
                text[row][col].setText("-");
                text[row][col].setTextColor(Color.parseColor("#666666"));
            }
        }
        currentState = PLAYING; // ready to play
        currentPlayer = CROSS;  // cross plays first
    }

    /** Player with the "theSeed" makes one move, with input validation.
     Update global variables "currentRow" and "currentCol". */
    public void playerMove(int theSeed) {
          // for input validation

            if (theSeed == CROSS) {
                System.out.print("Player 'X' : " + rowMove + ":" + colMove);
            } else {
                System.out.print("Player 'O' : " + rowMove + ":" + colMove);
            }

            if (rowMove >= 0 && rowMove < ROWS && colMove >= 0 && colMove < COLS && board[rowMove][colMove] == EMPTY) {
                currntRow = rowMove;
                currentCol = colMove;
                board[currntRow][currentCol] = theSeed;  // update game-board content
                validInput = true;  // input okay, exit loop
            }
            else
            {
                validInput = false;

                Toast.makeText(context, "InCorrect Move !!",
                        Toast.LENGTH_SHORT).show();

            }
    }

    public void decorate_winner()
    {

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {

        if(v == buttons[1][1])
        {
            rowMove = 1;
            colMove = 1;
        }
        else if(v == buttons[1][2])
        {
            rowMove = 1;
            colMove = 2;
        }else if(v == buttons[1][3])
        {
            rowMove = 1;
            colMove = 3;
        }else if(v == buttons[2][1])
        {
            rowMove = 2;
            colMove = 1;
        }
        else if(v == buttons[2][2])
        {
            rowMove = 2;
            colMove = 2;
        }else if(v == buttons[2][3])
        {
            rowMove = 2;
            colMove = 3;
        }else if(v == buttons[3][1])
        {
            rowMove = 3;
            colMove = 1;
        }
        else if(v == buttons[3][2])
        {
            rowMove = 3;
            colMove = 2;
        }
        else if(v == buttons[3][3])
        {
            rowMove = 3;
            colMove = 3;
        }
        else if(v == btnConnect)
        {
            Intent intent = new Intent(Main.this, ConnectionActivity.class);
            startActivity(intent);
        }

        if(currentState == PLAYING && v != btnConnect) {
            playerMove(currentPlayer); // update currentRow and currentCol

            if (validInput) {
                updateGame(currentPlayer, currntRow, currentCol); // update currentState
                // Switch player
                currentPlayer = (currentPlayer == CROSS) ? NOUGHT : CROSS;
            }
        }
            //printBoard();
            // Print message if game-over
            if (currentState == CROSS_WON) {
                System.out.println("'X' won! Bye!");
            } else if (currentState == NOUGHT_WON) {
                System.out.println("'O' won! Bye!");
            } else if (currentState == DRAW) {
                System.out.println("It's a Draw! Bye!");
            }
    }

    public void popup() {

        try {
            final Dialog dialog = new Dialog(this);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setContentView(R.layout.dialog);
            dialog.setCancelable(false);
            dialog.setCanceledOnTouchOutside(false);

            // dialog.setTitle(dialogHeader);


            TextView txtMsg2 = (TextView) dialog.findViewById(R.id.txtMsg2);

            TextView btnPlay = (TextView) dialog.findViewById(R.id.btnPlay);
            TextView btnCancel = (TextView) dialog.findViewById(R.id.btnCancel);

            switch(currentState)
            {
                case 1: txtMsg2.setText("Game DRAWN !");
                        break;

                case 2: txtMsg2.setText("CROSS Won the Game !");
                        break;

                case 3: txtMsg2.setText("NOUGHT Won the Game !");
                        break;
            }


            btnCancel.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    // TODO Auto-generated method stub
                    dialog.dismiss();

                    finish();

                }
            });

            btnPlay.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    // TODO Auto-generated method stub
                    dialog.dismiss();
                    initGame();

                }
            });

            dialog.show();
        } catch (Exception e) {

            Toast.makeText(context, "Application Encountered some problem !!",
                    Toast.LENGTH_LONG).show();
        }
    }
}
